from elements.game.main_menu.main_menu import *

pygame.init()

pygame.display.set_caption("Bound")

main_menu()
